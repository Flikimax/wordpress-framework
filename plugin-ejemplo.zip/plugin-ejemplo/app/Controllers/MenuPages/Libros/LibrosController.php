<?php
/**
 * Menu Page Libros.
 */

namespace PluginEjemplo\Controllers\MenuPages\Libros;

use PluginEjemplo\Controllers\MenuPages\Libros\Categorias;

class LibrosController
{
    # Opcionales.
    # https://developer.wordpress.org/reference/functions/add_menu_page
    public static $pageTitle  = 'Fw Libros';
    public static $menuTitle  = 'Fw Libros';
    public static $capability = 'install_plugins';
    public static $menuSlug   = 'fw-libros';
    public static $icon       = 'dashicons-book-alt';
    public static $position   = '1';
    
    /**
     * Metodo por default.
     *
     **/
    public function index()
    {
        return view('menuPages/libros/layout', [
            'content' => view('menuPages/libros/index', [
                'categoryList' => $this->getCategoryList(),
            ]),
        ]);
    }

    /**
     * Obtiene la lista de categorias.
     * Método no accesible por url (privado). 
     *
     * @return array
     **/
    private function getCategoryList() : array
    {
        return Categorias::$list;
    }

    /**
     * Página de error 404.
     *
     **/
    public function error404()
    {
        return view('menuPages/libros/layout', [
            'content' => view('menuPages/404')
        ]);
    }

}
