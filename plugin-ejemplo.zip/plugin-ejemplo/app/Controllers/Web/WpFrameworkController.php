<?php 

namespace PluginEjemplo\Controllers\Web;

use PluginEjemplo\Models\Ejemplo;

class WpFrameworkController  
{
    /** @var string $routeUrl URL que ejecutara este controlador. tusitio.com/wp-framework */
    public static string $routeUrl = '/wp-framework';
    /** @var bool $routeForce Forzar la URL (sobreescribe las URLs de WordPress). */
    public static bool $routeForce = true;
    /** @var bool $enableUri Habilita el uso de métodos por medio de url: tusitio.com/wp-framework/gettingStarted */
    public static bool $enableUri = true;
    /** @var object $model Modelo de ejemplo. */
    public object $model;

    # Constructor
    public function __construct ()
    { 
        $this->model = new Ejemplo;
    }
    
    /**
     * Método defaul: tusitio.com/wp-framework
     * 
     * @return Response
     */
    public function index()
    {
        return view('web/layout', [
            'content' => view('web/index'),
        ]);
    }

    /**
     * Método que se ejecutara al entrar a la url: tusitio.com/wp-framework/gettingStarted
     * 
     * @return Response
     */
    public function gettingStarted()
    {
        return view('web/layout', [
            'content' => view('web/gettingStarted'),
        ]);
    }

    /**
     * Método que se ejecuta cuando no se encuentra una ruta.
     * 
     * @return Response
     */
    public function error404()
    {
        return view('web/layout', [
            'content' => view('web/404', [
                'titulo' => asset('images/error404.svg')
            ]),
        ]);
    }

    # Método privado - No accecible desde url.
    private function private()
    {
        echo "No accesible por URL.";
    }
}
