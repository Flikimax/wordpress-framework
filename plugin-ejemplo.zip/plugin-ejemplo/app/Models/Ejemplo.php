<?php 
# Modelo de ejemplo.

namespace PluginEjemplo\Models;

class Ejemplo  
{
    # Constructor
    public function __construct ()
    { 
        
    }
}
