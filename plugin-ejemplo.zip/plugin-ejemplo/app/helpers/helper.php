<?php
/**
 * Convierte un texto a mayuscula.
 *
 * @param string $text Texto para convertir a mayuscula.
 * @return string
 **/
function upper(string $text) : string
{
    return strtoupper($text);
}