<h1>Cómo empezar.</h1>


<div class="d-flex align-items-start tabs-getting-started">

    <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
        <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Instalación</button>
        <button class="nav-link" id="v-pills-directory-structure-tab" data-bs-toggle="pill" data-bs-target="#v-pills-directory-structure" type="button" role="tab" aria-controls="v-pills-directory-structure" aria-selected="false">Estructura de Carpetas</button>
        <button class="nav-link" id="v-pills-menu-pages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-menu-pages" type="button" role="tab" aria-controls="v-pills-menu-pages" aria-selected="false">Menu Pages</button>
        <button class="nav-link" id="v-pills-web-tab" data-bs-toggle="pill" data-bs-target="#v-pills-web" type="button" role="tab" aria-controls="v-pills-web" aria-selected="false">Web</button>
    </div>

    <div class="tab-content" id="v-pills-tabContent">
        <!-- INSTALACION -->
        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
            <h3>Instalación</h3>

            <ol>
                <li><strong><a href="https://flikimax.com/wp-fw/wp-framework.zip">Descarga</a></strong> el archivo .zip del plugin.</li>
                <li>
                    Ingresa a tu Panel de WordPress y ve a <strong>Plugins -> Agregar Nuevo</strong>.
                    <img src="https://trello.com/1/cards/61a0406f1fec956980fdbfff/attachments/61a044287832094a2d12c54e/download/Upload_Plugins.jpg" alt="Upload Plugins">
                </li>

                <li>
                    Haz clic en el botón <strong>Subir Plugin</strong> en la parte superior de la página.
                    <img src="https://trello.com/1/cards/61a0406f1fec956980fdbfff/attachments/61a0450b44a754515178b145/download/Instalar_Ahora.png" alt="Instalar Ahora">
                </li>

                <li>
                    Haz clic en <strong>Examinar</strong> y <strong>selecciona el archivo</strong> del plugin de tu ordenador.
                </li>

                <li>
                    Presiona <strong>Instalar ahora</strong>.
                </li>

                <li>
                    Una vez terminada la instalación, haz clic en <strong>Activar Plugin</strong>.
                </li>
            </ol>

        </div>


        
        <div class="tab-pane fade" id="v-pills-directory-structure" role="tabpanel" aria-labelledby="v-pills-directory-structure-tab">
        
            <h3>Estructura de Carpetas</h3>

            <pre>
- wp-content
    - plugins
        - plugin-ejemplo
            - app
                -assets 
                    - admin
                        - css
                        - images
                        - js
                    - css
                    - images
                    - js
                - Controllers
                    - MenuPages
                        - Libros
                            - Categorias.php
                            - LibrosController.php
                    - Web
                        - WpFrameworkController.php
                - helpers
                - Models
                - views
            - autoload
            </pre>
        </div>
        
        <!-- MENU PAGES -->
        <div class="tab-pane fade" id="v-pills-menu-pages" role="tabpanel" aria-labelledby="v-pills-menu-pages-tab">
            <h3>Menu Pages (Controllers)</h3>

            <p>Las Menu Page se disponen de padres e hijos, es decir, Menu Page que pueden contener Sug Menu Page.</p> 

            <p>Las Menu Page seran agregadas automaticamente si se sigue la estructura indicada:</p>

            <h4>Estructura: </h4>

            <pre>
- wp-content
    - plugins
        - plugin-ejemplo
            - app
                - Controllers
                    - MenuPages
                        - Libros
                            - Categorias.php
                            - LibrosController.php
            </pre>

            <ol>
                <li>
                    <strong>Libros</strong> sera la Menu Page principal (padre).
                    <img src="https://trello.com/1/cards/61a0406f1fec956980fdbfff/attachments/61a2d0272165f54ceb59fc4c/download/Menu_Page%2C_Libros.png" alt="Menu Page Libros">
                </li>

                <li>
                    <strong>Categorias</strong> sera una Sub Menu Page (hijos) de <strong>Libros</strong>.
                    <img src="https://trello.com/1/cards/61a0406f1fec956980fdbfff/attachments/61a2d029f10b7f0e02e283f2/download/Sub_Menu_Page%2C_Categorias.png" alt="Sub Menu Page Categorias">
                </li>
            </ol>

            <p>No es requerido adicionar la palabra 'Controller' pero como buenas practicas es recomentado.</p>

            <h4>Método por default</h4>

            <p>El método por default es <code>index</code>, es el método que se buscará en caso de no enviarse ningun otro.</p>

            <h4>Visibilidad de los métodos</h4>

            <p><strong>Nota:</strong> Solo son accesibles por url los métodos publicos.</p>

            <p>Los demas métodos (privados o protegidos) seran accesibles normalmente como lo indica el propio lenguaje.</p>

            <a href="https://www.php.net/manual/es/language.oop5.visibility.php" target="_blank">Más información.</a>
        </div>

        
        <!-- WEB -->
        <div class="tab-pane fade" id="v-pills-web" role="tabpanel" aria-labelledby="v-pills-web-tab">
            <h3>Web (Controllers)</h3>

            <p>
                Los controladores Web permiten crear URLs accesibles como por ejemplo: <code>tusitio.com/wp-framework</code>
            </p>
            <p>
                Esta URL principal buscará un controlador con el nombre <code>WpFrameworkController</code> y el método por default <code>index</code>.
            </p>
            <p>
                Para usar URLs que extienden a la principal, como por ejemplo: <code>tusitio.com/wp-framework/gettingStarted</code>, basta con crear un método público con el nombre <code>gettingStarted</code> en el controlador <code>WpFrameworkController</code>.
            </p>

            <h4>Estructura: </h4>

            <pre>
- wp-content
    - plugins
        - plugin-ejemplo
            - app
                - Controllers
                    - Web
                        - WpFrameworkController.php

            </pre>

            <h4>Controlador Web: <code>WpFrameworkController</code></h4>

            <img src="https://trello.com/1/cards/61a0406f1fec956980fdbfff/attachments/61aed80b05d6d978c5673d42/download/Controlador_Web.png" alt="Controlador Web">

        </div>

    </div>

</div>
