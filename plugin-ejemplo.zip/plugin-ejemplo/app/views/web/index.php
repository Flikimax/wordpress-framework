<div class="wpfw-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                
                <div>
                    <h1 align="center" style="color: #0d6af5 !important;">Wp Framework</h1>
    
                    <p align="center">
                        <a href="https://flikimax.com/wp-fw/wp-framework.zip" target="_blank">
                            <img src="https://flikimax.com/wp-fw/wp-fw-download.svg" />
                        </a> 
                        
                        <a href="#"><img src="https://flikimax.com/wp-fw/wp-fw-last-version.svg" />
                        </a>
                        
                        <a href="https://github.com/Flikimax/Wp-Framework/blob/main/LICENSE" target="_blank">
                            <img src="https://flikimax.com/wp-fw/wp-fw-license.svg" />
                        </a>
                    </p>
                </div>

                <div class="description">
                    <h3>Descripción</h3>
    
                    <p>Es un framework desarrollado para el CMS WordPress que hace uso del patrón de arquitectura mvc (modelo-vista-controlador), esto con la intensión de ayudar y disminuir el tiempo de desarrollo de sistemas.
                    La idea original y la primera versión fue planteada y desarrollada por el <strong><a href="https://www.linkedin.com/in/ingenieroleon">Ingeniero César León</a></strong>, CEO de la empresa <strong><a href="https://colombiavip.com">ColombiaVIP</a></strong>, la cual cuenta con más de 15 años de experiencia en la creación y diseño de páginas web.
                    Este proyecto se hace <strong>Open Source</strong> y será encabezado por <strong><a href="https://flikimax.com">Flikimax</a></strong> para su reestructuración, se tomara como punto de partida, la idea original, un framework mvc para Wordpress.
                    </p>

                    <a class="link" href="/wp-framework/gettingStarted">Comenzar</a>
                </div>

            </div>
        </div>
    </div>


</div>


